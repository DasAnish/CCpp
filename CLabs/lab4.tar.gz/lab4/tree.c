#include <stdlib.h>
#include "tree.h"

Tree *empty = NULL;

/* BASE EXERCISE */

int tree_member(int x, Tree *tree) { 
  /* TODO */
  return 0;
}

Tree *tree_insert(int x, Tree *tree) { 
  /* TODO */
  return empty;
}

void tree_free(Tree *tree) { 
  /* TODO */
}

/* CHALLENGE EXERCISE */ 

void pop_minimum(Tree *tree, int *min, Tree **new_tree) { 
  /* TODO */
}

Tree *tree_remove(int x, Tree *tree) { 
  /* TODO */
  return empty;
}
